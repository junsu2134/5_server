/* function displayImage(binaryData) {
  // 이미지 요소 생성
  var img = document.createElement("img");
  img.setAttribute("src", "data:image/jpeg;base64," + binaryData); // 이진 데이터를 Data URL로 변환하여 src 속성에 설정

  // 이미지를 출력할 요소 선택 (예: <div id="image-container"></div>)
  var imageContainer = document.querySelector("#sample");

  // 이미지 요소를 선택한 요소에 추가
  imageContainer.appendChild(img);
}

// 이진 데이터를 화면에 출력
displayImage(binaryImageData); */