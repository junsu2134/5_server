const btn = document.getElementsByClassName("C-cancelbtn");
const cla = document.getElementsByClassName("C-rsvlist-container");

for(let i = 0; i <cla.length; i++){

    btn[i].addEventListener("click",function(){
        cla[i].class
    })

    }


