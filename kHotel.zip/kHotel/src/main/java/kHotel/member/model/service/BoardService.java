package kHotel.member.model.service;

import java.sql.Connection;

import kHotel.member.model.vo.Board;

public class BoardService {

	public Board mypageWirte() {
		

		
		return null;
	}



	
}
