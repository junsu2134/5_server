package kHotel.member.model.service;

public class MemberService {

	public MemberService() {
		// TODO Auto-generated constructor stub
	}

}
