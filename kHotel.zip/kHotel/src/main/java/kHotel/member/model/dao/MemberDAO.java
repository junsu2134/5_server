package kHotel.member.model.dao;

public class MemberDAO {

	public MemberDAO() {
		// TODO Auto-generated constructor stub
	}

}
