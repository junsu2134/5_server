package kHotel.member.model.dao;

public class BoardDAO {

	public BoardDAO() {
		// TODO Auto-generated constructor stub
	}

}
